/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import modelo.Modelo;
import util.Conecta;

/**
 *
 * @author User
 */
public abstract class ModeloDAO {

    private ModeloDAO(){
    }
    
    public static void inserirModelo(Modelo modelo) {
        String sql = "insert into Modelo (nome, numero) values (?, ?)";
        System.out.print("Senha MySQL: ");
        Conecta conexao = new Conecta(new Scanner(System.in).nextLine());
        conexao.criarStatement(sql);
        conexao.setString(1, modelo.getNome());
        conexao.setInt(2, modelo.getNumero());
        conexao.executar();
        conexao.fechar();
    }
    
    public static List<Modelo> listarModelo(){
        List<Modelo> lista = new ArrayList<>();
        for(int i = 1; i <= 10; i++){
            Modelo novo = new Modelo();
            novo.setNome("Modelo " + i);
            lista.add(novo);
        }
        return lista;
    }
    
    public static List<Modelo> listaModelo(){
        try {
            String sql = "select * from Modelo";
            System.out.print("Senha MySQL: ");
            Conecta conexao = new Conecta(new Scanner(System.in).nextLine());
            conexao.criarStatement(sql);
            conexao.executar();
            ResultSet resultado = conexao.getResultSet();
            List<Modelo> lista = new ArrayList<>();
            while(resultado.next()){
                Modelo novo = new Modelo();
                novo.setNome(resultado.getString("nome"));
                novo.setNumero(resultado.getInt("numero"));
                lista.add(novo);
            }
            resultado.close();
            conexao.fechar();
            return lista;
        } catch (SQLException ex) {
            System.err.println("Erro! " + ex.getMessage());
            return null;
        }
    }
}
