/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Classe não está construída - NÃO VAI FUNCIONAR
 * @author User
 */
public class Conecta {
    private String BD = "DBModelo";
    private final String URL = "jdbc:mysql://localhost:3306/" + BD;
    private String USERNAME = "root";
    private String PASSWORD;
    private Connection conexao;
    private PreparedStatement statement;
    
    public Conecta(String password){
        try {
            this.PASSWORD = password;
            this.conexao = (Connection) DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (SQLException ex) {
            System.err.println("Erro! " + ex.getMessage());
        }
    }

    public Connection getConexao() {
        return conexao;
    }

    public PreparedStatement getStatement() {
        return statement;
    }

    public void criarStatement(String sql) {
        try {
            this.statement = conexao.prepareStatement(sql);
        } catch (SQLException ex) {
            System.err.println("Erro! " + ex.getMessage());
        }
    }

    public void executar() {
        try {
            this.statement.execute();
        } catch (SQLException ex) {
            System.err.println("Erro! " + ex.getMessage());
        }
    }

    public ResultSet getResultSet() {
        try {
            return statement.getResultSet();
        } catch (SQLException ex) {
            System.err.println("Erro! " + ex.getMessage());
            return null;
        }
    }

    public void fechar() {
        try {
            this.statement.close();
            this.statement = null;
            this.conexao.close();
        } catch (SQLException ex) {
            System.err.println("Erro! " + ex.getMessage());
        }
    }

    public void setString(int idx, String name) {
        try {
            this.statement.setString(idx, name);
        } catch (SQLException ex) {
            System.err.println("Erro! " + ex.getMessage());
        }
    }

    public void setInt(int idx, int num) {
        try {
            this.statement.setInt(idx, num);
        } catch (SQLException ex) {
            System.err.println("Erro! " + ex.getMessage());
        }
    }

    public void setDate(int idx, Date date) {
        try {
            this.statement.setDate(idx, date);
        } catch (SQLException ex) {
            System.err.println("Erro! " + ex.getMessage());
        }
    }

    public void setDouble(int idx, double num) {
        try {
            this.statement.setDouble(idx, num);
        } catch (SQLException ex) {
            System.err.println("Erro! " + ex.getMessage());
        }
    }

}
