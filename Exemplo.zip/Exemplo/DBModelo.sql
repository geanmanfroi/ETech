create database DBModelo;
use DBModelo;

create table Modelo(
	idModelo int auto_increment not null,
    nome varchar(255),
    numero int,
    primary key (idModelo)
);